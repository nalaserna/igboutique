<?php

# Silence is golden.